
from .multiple import MultiplePi

__version__ = "1.2.0"
