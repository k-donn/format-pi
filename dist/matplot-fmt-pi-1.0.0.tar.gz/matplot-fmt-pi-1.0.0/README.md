# Matplotlib Format Pi

Create locator and formatter instances that format multiples of pi.